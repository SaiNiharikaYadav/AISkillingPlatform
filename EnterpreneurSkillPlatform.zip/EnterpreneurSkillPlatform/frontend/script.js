document.querySelector("form").addEventListener("submit", function (e) {
  e.preventDefault();

  const email = document.querySelector("input[type='email']").value;
  const password = document.querySelector("input[type='password']").value;

  fetch("http://127.0.0.1:5000/login", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ email, password }),
  })
    .then((response) => {
      if (!response.ok) {
        throw new Error("Network response was not ok");
      }
      return response.json();
    })
    .then((data) => {
      if (data && data.message) {
        alert(data.message);
      } else {
        alert("Unexpected server response");
      }
    })
    .catch((error) => {
      console.error("Error:", error);
      alert("Server error: " + error.message);
    });
});
