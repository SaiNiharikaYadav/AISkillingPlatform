from flask import Flask, request, jsonify, render_template
import sqlite3
import os
from flask_cors import CORS

app = Flask(__name__)
CORS(app)  # 👈 Enable CORS globally


# Initialize SQLite DB
def init_db():
    conn = sqlite3.connect('entrepreneur.db')
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT NOT NULL,
            password TEXT NOT NULL
        )
    ''')
    c.execute('''
        CREATE TABLE IF NOT EXISTS scores (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT NOT NULL,
            course TEXT NOT NULL,
            score INTEGER NOT NULL
        )
    ''')
    conn.commit()
    conn.close()

init_db()

@app.route("/")
def index():
   return render_template("index.html")


@app.route("/login", methods=["POST"])
def login():
    data = request.json
    email = data.get("email")
    password = data.get("password")
    
    conn = sqlite3.connect('entrepreneur.db')
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE email = ? AND password = ?", (email, password))
    user = c.fetchone()
    
    if user:
        return jsonify({"status": "success"})
    else:
        c.execute("INSERT INTO users (email, password) VALUES (?, ?)", (email, password))
        conn.commit()
        return jsonify({"status": "registered"})

@app.route("/submit-quiz", methods=["POST"])
def submit_quiz():
    data = request.json
    email = data["email"]
    course = data["course"]
    score = data["score"]
    
    conn = sqlite3.connect('entrepreneur.db')
    c = conn.cursor()
    c.execute("INSERT INTO scores (email, course, score) VALUES (?, ?, ?)", (email, course, score))
    conn.commit()
    return jsonify({"message": "Score saved!"})

@app.route("/scores", methods=["GET"])
def all_scores():
    conn = sqlite3.connect('entrepreneur.db')
    c = conn.cursor()
    c.execute("SELECT email, course, score FROM scores ORDER BY score DESC")
    scores = c.fetchall()
    return jsonify(scores)

if __name__ == "__main__":
    app.run(debug=True)
